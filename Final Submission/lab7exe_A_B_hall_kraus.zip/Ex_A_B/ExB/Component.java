/* File Name: Component.java
 * Lab # and Assignment #: Lab #7
 * Lab section: 1
 * Completed by: Graydon Hall and Jared Kraus
 * Submission Date: 2021-11-22
 */

package ExB;

import java.awt.*;

public interface Component {
    public void draw(Graphics g);
}
