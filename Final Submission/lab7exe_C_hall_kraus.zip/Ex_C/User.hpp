/* File Name: User.hpp
* Lab # and Assignment #: Lab #7
* Lab section: 1
* Completed by: Graydon Hall and Jared Kraus
* Submission Date: 2021-11-22
*/

#ifndef USER
#define USER
#include <string>
using namespace std;

struct User
{
    string username;
    string password;
};

#endif
